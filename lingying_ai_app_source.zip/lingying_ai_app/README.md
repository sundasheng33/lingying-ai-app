# 灵影 AI 视频工厂（Android 第一版）

## 当前版本包含
- 安卓原生 WebView 外壳，可安装为 APK
- 中文首页、文字/图片创作工作台
- 图片/视频素材选择与预览
- 比例、时长、配音、字幕参数选择
- 创作方案整理与复制

## 重要说明
本版本是第一版可运行界面原型，尚未接入真正的云端 AI 视频生成 API，因此不会声称已能一键生成视频。免费生成服务需要后续确定供应商、地区可用性、免费额度及 API 接入方式。不要把任何服务密钥写入 APK 前端。

## 生成 APK（无需本地 Android Studio）
1. 将整个项目上传到自己的 GitHub 仓库。
2. 打开仓库的 Actions 页面，选择 `Build Android APK`。
3. 点击 `Run workflow`，等待构建完成。
4. 打开本次运行记录，在 Artifacts 下载 `LingYing-AI-Video-APK`，解压后得到 `app-debug.apk`。
5. 将 APK 下载到安卓手机，允许浏览器/文件管理器安装该来源应用后安装。

## 技术参数
- applicationId: com.lingying.aivideo
- minSdk: 23 (Android 6.0+)
- targetSdk: 35
- version: 1.0.0
